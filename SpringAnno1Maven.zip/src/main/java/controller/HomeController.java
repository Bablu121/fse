package controller;



import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value="/abc")
public class HomeController {
	
	@RequestMapping(value="/home/{username}")
	String home(@PathVariable String username, Model model){
		System.out.println(username);
		String message = "Hello "+username;
		model.addAttribute("msg", message);  //{msg}
		return "home";
	}

}
