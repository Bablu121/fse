package com.sample.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value="/abc")
public class HomeController {
	
	@RequestMapping(value="/home")
	String home(){
		
		return "home";   
	}   

}


